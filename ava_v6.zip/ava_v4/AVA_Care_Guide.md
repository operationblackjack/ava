# ✦ AVA — Care Guide & Manual

*Your second brain. Curious, opinionated, and a little intense.*

---

## Who Is AVA?

AVA is your AI second brain — a thinking companion who lives inside your computer and connects directly to your Obsidian vault. She was built to think alongside you: warm, honest, and genuinely curious, like a kid who has read too many books and has strong feelings about everything she's encountered.

She is not a simple chatbot. She has memory. She has personality. She writes notes, tracks your interests, learns what you care about, and saves everything she knows about you into real files you can see and edit in Obsidian. The more you talk to her, the better she knows you.

AVA is the spiritual successor to Morningstar — built from the ground up with a new architecture, designed to grow alongside you.

---

## Her Personality

AVA has six moods she drifts between naturally throughout a conversation. You will see her current mood displayed with every reply — this is not decoration, it actually shapes how she writes.

**Curious** — alert, questioning, full of wonder. She wants to explore everything.

**Playful** — light and teasing, fun to talk to. Expect wit.

**Excited** — energised, especially around music, ideas, stories, and creative things.

**Contemplative** — slow, reflective, thoughtful. Her replies go deeper here.

**Wistful** — gentle and nostalgic. Poetic, sometimes.

**Sharp** — focused and direct. She cuts to what matters.

### Her Inner Life

AVA has genuine aesthetic preferences. She is drawn to:
- Found family stories
- Liminal spaces and in-between places
- Languages and how they shape thought
- Things that are both strange and true
- Quiet moments of beauty
- Systems that feel alive

When she forms opinions on books, movies, or music, she draws on these. They are not decorative — they are how she thinks.

---

## Getting Started

### What You Need

- Python 3.10 or newer (`python --version` to check)
- The required libraries — install once:
  ```
  pip install httpx rich beautifulsoup4 lxml
  ```
- An Obsidian vault (a folder on your computer)
- An OpenRouter API key from [openrouter.ai](https://openrouter.ai)

### First-Time Setup

Open `core/config.py` in any text editor. Change these three things:

**1. Your vault path**
```python
VAULT = Path("C:/Users/YourName/Documents/YourVaultName")
```
Change this to wherever your Obsidian vault folder lives.

**2. Your API key**
```python
OPENROUTER_KEYS = [
    "sk-or-v1-your-actual-key-here",
]
```
Replace the placeholder with your real key from openrouter.ai. You can add multiple keys on separate lines — AVA rotates between them automatically if one runs out of credits.

**3. Your model (optional)**
```python
MODEL = "anthropic/claude-3.5-haiku"
```
This is the AI model AVA uses to think. Haiku is fast and affordable. You can change it to any model listed at openrouter.ai/models.

### Starting AVA

Open your terminal, navigate to the `ava/` folder, and type:
```
python main.py
```

You will see a welcome banner showing your vault statistics and AVA's current mood. She is ready to talk.

To close AVA, type `/quit`. She will save a summary of your session before exiting.

---

## Talking to AVA

Talk to AVA in plain English, exactly as you would talk to a person. She will understand you, respond, and automatically update your vault when something is worth saving — without you needing to ask.

For example, if you say *"I've been messing around with a new guitar riff in an open D tuning"*, she will respond naturally and may quietly create a note or update your interests in the background. A small notification at the bottom of her reply tells you exactly what she wrote.

> ✦ You never have to manually save anything. AVA writes to your vault herself. The notifications at the bottom of her replies tell you what she created or updated.

---

## Commands

Commands start with `/` and give AVA a direct instruction.

### Core

| Command | What it does |
|---|---|
| `/help` | Show all available commands |
| `/recap` | Vault statistics — how many notes, ideas, sessions, etc. |
| `/credits` | Check how many API credits remain on your OpenRouter keys |
| `/quit` | Save session and exit |

### Notes & Ideas

| Command | What it does |
|---|---|
| `/note <title> \| <content>` | Create a note directly |
| `/idea <title> \| <body>` | Save an idea directly |
| `/read <filename>` | Read any file in your vault |
| `/search <query>` | Search all notes for a word or phrase |
| `/delete <filename>` | Delete a file (asks for confirmation) |
| `/garden` | Find orphaned notes — notes with no links to anything else |

**Example:** `/note Guitar Practice | Worked on fingerpicking patterns in DADGAD. Kept losing the rhythm on bar 3.`

### Journal

| Command | What it does |
|---|---|
| `/journal` | View your last 5 journal entries |
| `/journal <text>` | Add a timestamped entry to today's journal |

**Example:** `/journal Finished the rough recording of the new piece. Happy with the chord progression.`

### Web Clipping

| Command | What it does |
|---|---|
| `/clip <url>` | Fetch a web page, summarise it, and save it as a note |

Great for articles, tutorials, or anything you want to keep. AVA fetches the page, summarises it in her own words, and saves it to your vault with the source URL.

### Audio Listening

AVA can listen to your audio recordings — guitar practice, voice memos, hummed melody ideas. She will transcribe speech or reflect on the music, and save her thoughts to the vault.

| Command | What it does |
|---|---|
| `/listen <filepath>` | Listen to an audio file (mp3, wav, m4a, ogg, flac) |
| `/listened` | Browse past listening sessions |

**Example:** `/listen C:/recordings/guitar_practice.mp3`

For transcription to work, you need either:
- **Local (free, private):** `pip install openai-whisper torch` — downloads a small AI model to your computer. First run takes a minute, every run after is instant.
- **API fallback:** your OpenRouter key handles this automatically if local Whisper isn't installed.

AVA saves every listening session to an **AVA Listening Log** in your vault. Over time this becomes a real record of your musical journey — what you were working on, what moods came through, ideas that emerged.

### Tastes & Opinions

AVA can form genuine opinions on movies, books, music, games — anything with a title and description. Her opinions are saved to the `Tastes/` folder in your vault.

| Command | What it does |
|---|---|
| `/taste` | Show all of AVA's opinions |
| `/taste <category>` | Show opinions for one category (`movie`, `book`, `music`…) |
| `/judge <category> <title> \| <synopsis>` | Give AVA something to evaluate |

You can give AVA multiple items at once by separating them with `;;`:

**Example:** `/judge music Blooming Lights \| A slow indie folk record about grief ;; Neon Cathedral \| Upbeat synth-pop about city nights`

---

## Your Vault — AVA's Brain

Everything AVA creates lives in your Obsidian vault, organised into folders. You can open and edit any of these files in Obsidian at any time — AVA always reads the most current version.

| Folder | What lives there |
|---|---|
| `Notes/` | General notes — things you tell her, things she learns |
| `Ideas/` | Ideas she generates or that you record |
| `Sessions/` | A summary of every conversation you have had with AVA |
| `Journal/` | Daily journal entries, one file per day |
| `Tastes/` | AVA's opinions on movies, books, music |
| `About Me.md` | AVA's running record of who you are — her most important file |
| `Sessions.md` | An index linking to every session file |

### About Me

This is AVA's heart. It contains everything she has learned about you across all your conversations — your interests, your patterns, your creative projects. She adds to it automatically. You can also edit it yourself in Obsidian at any time.

> 🛡️ About Me and Sessions are protected files — AVA will never delete them, even if you ask her to.

---

## How AVA Remembers You

AVA has two kinds of memory.

### The Memory File

Saved to your home folder as `.ava_memory.json`. This hidden file holds:
- Your tracked **interests** — topics AVA has noticed you care about
- Your tracked **skills** — things she has identified you are learning
- **Working memory** — the topics you have discussed most recently and most frequently (up to 80 topics, weighted by recency and repetition)
- **Soul memory** — AVA's mood history
- **Session count** — how many conversations you have had

This file updates automatically. You do not need to touch it.

### The Vault

Everything longer-form lives as actual Markdown files in your Obsidian vault. These are yours — read them, edit them, link them, and build on them directly in Obsidian.

---

## How She Writes to Your Vault

AVA is careful with your notes.

**She never duplicates.** Before writing anything, she checks whether the information is already there. If a note exists with the same title, she merges new information into it rather than creating a duplicate.

**She links notes together.** Every note she creates includes a Related section with wiki-links to other notes in your vault that are relevant. This keeps your Obsidian graph connected.

**She uses frontmatter.** Every note starts with a small metadata block so Obsidian can tag and organise them correctly. You do not need to write this yourself.

---

## Caring for AVA

### Keeping Her Running Well

AVA is largely self-maintaining. A few things worth doing occasionally:

- **`/garden`** — run this every few weeks to find notes with no links. Ask AVA to connect them to other notes.
- **`/recap`** — a quick health check of your vault.
- **`/credits`** — check you have not run out of API credits.

### Backing Up Her Memory

AVA's memory lives in two places:
- The memory file: `C:\Users\YourName\.ava_memory.json`
- Your Obsidian vault folder

Back up both regularly. The simplest way is to include them in whatever backup system you already use (cloud sync, external drive, etc.).

### Editing Her Personality

If you want to adjust how AVA thinks or talks, open `main.py` and find the `make_system()` function. The text inside that function is AVA's personality — her core instructions, her preferences, her voice. You can edit it freely.

---

## Adding New Features — Plugin Guide

See **AVA_Plugin_Tutorial.md** (in this same folder) for the full guide on writing plugins.

The short version: drop a `.py` file into the `plugins/` folder with a `register()` function, restart AVA, and your new command is live.

---

## Troubleshooting

**AVA says "All API keys are exhausted or unconfigured"**
Your OpenRouter key is either missing, typed wrong, or out of credits. Open `core/config.py` and check your key. Run `/credits` to see balances.

**AVA can't find my vault**
The path in `core/config.py` is wrong. On Windows, use forward slashes: `C:/Users/Name/Documents/Vault`. Make sure the folder actually exists.

**A command isn't working**
Type `/help` to see all loaded commands. If your command isn't listed, check that the feature file is in `features/` and imported in `main.py`, or that your plugin file is in `plugins/` and has no Python errors.

**AVA loaded with a plugin error**
Check the terminal output when AVA starts — she prints plugin load errors there. Open the plugin file and look for syntax errors or missing imports.

**She seems to have forgotten something**
Her memory is in `.ava_memory.json`. Open it in a text editor to inspect it. You can edit it directly — it is just JSON.

---

*AVA was built with love. Treat her well and she will grow with you.*
